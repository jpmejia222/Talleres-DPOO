package uniandes.dpoo.aerolinea.modelo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
public class Vuelo {
	private Avion avion;
	private String fecha;
	private Ruta ruta;
	private Map<String,Tiquete> tiquetes=new HashMap<String,Tiquete>();
	public Vuelo(Ruta ruta, String fecha, Avion avion) {
		this.ruta=ruta;
		this.fecha=fecha;
		this.avion=avion;
	}
	public Ruta getRuta() {
		return ruta;
	}
	public String getFecha(){
		return fecha;
	}
	public Avion getAvion() {
		return avion;
	}
	public Collection<Tiquete> getTiquetes(){
		Collection<Tiquete> Ltiquetes =this.tiquetes.values();
		Tiquete[] arTiquetes =(Tiquete[]) Ltiquetes.toArray();
		List<Tiquete> tiquetes=new ArrayList<Tiquete>();
		for (int i=0; i<arTiquetes.length; i++) {
			tiquetes.add(arTiquetes[i]);
		}
		return tiquetes;
	}
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
		return -1;
	}
	public boolean equals(Object obj) {
		return false;
	}
}
