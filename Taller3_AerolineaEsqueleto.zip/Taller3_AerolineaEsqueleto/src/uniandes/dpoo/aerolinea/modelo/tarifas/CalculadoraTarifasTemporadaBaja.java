package uniandes.dpoo.aerolinea.modelo.tarifas;

public class CalculadoraTarifasTemporadaBaja {

}
