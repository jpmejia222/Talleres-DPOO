package uniandes.dpoo.aerolinea.modelo.tarifas;
import java.util.List;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
public abstract class CalculadoraTarifas {
	public static double IMPUESTO=0.28;
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		return -1;
	}
	protected abstract 
}
