package uniandes.dpoo.aerolinea.modelo.cliente;
import java.util.LinkedList;
import java.util.List;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;
public abstract class Cliente {
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	public Cliente(){
		tiquetesSinUsar=new LinkedList<Tiquete>();
		tiquetesUsados=new LinkedList<Tiquete>();
	}
	public abstract String getTipoCliente();
	public abstract String getIdentificador(); 
	public void agregarTiquete(Tiquete tiquete) {
		tiquetesSinUsar.add(tiquete);
	}
	public int calcularValorTotalTiquete() {
		int total=0;
		int sizeUsados=tiquetesSinUsar.size();
		int sizeSinUsar=tiquetesUsados.size();
		for(int i=0; i<sizeSinUsar;i++) {
			Tiquete tiquete=tiquetesSinUsar.get(i);
			int tarifa=tiquete.getTarifa();
			total=+tarifa;
		}
		for(int i=0; i<sizeUsados;i++) {
			Tiquete tiquete=tiquetesUsados.get(i);
			int tarifa=tiquete.getTarifa();
			total=+tarifa;
		}
		return total;
	}
	public void usarTiquetes(Vuelo vuelo) {
		int sizetiquetes=tiquetesSinUsar.size();
		for(int i=0;i<sizetiquetes;i++) {
			Tiquete tiquete=tiquetesSinUsar.get(i);
			if((tiquete.getVuelo()).equals(vuelo)) {
				tiquete.marcarComoUsado();
				tiquetesSinUsar.remove(i);
				tiquetesUsados.add(tiquete);
			}
		}
	}
}
