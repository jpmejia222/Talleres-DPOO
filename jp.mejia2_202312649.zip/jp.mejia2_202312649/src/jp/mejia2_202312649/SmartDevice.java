package jp.mejia2_202312649;

public abstract class SmartDevice {
	private boolean isOn;
	private int id;
	public SmartDevice(int id) {
		SmartDevice= new int p
	}
	
}
