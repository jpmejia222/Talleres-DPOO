package jp.mejia2_202312649;

public class SmartThermostat {

}
