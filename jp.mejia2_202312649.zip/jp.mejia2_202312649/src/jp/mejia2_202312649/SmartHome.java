package jp.mejia2_202312649;

public class SmartHome 
{   
	public SmartHome() {
		
	}
	public void addDevice(Device device) {
		
	}
	public void removeDevice(Device device) {
		
	}
	public String getAllStatuses() {
		return null;
		
	}
}
