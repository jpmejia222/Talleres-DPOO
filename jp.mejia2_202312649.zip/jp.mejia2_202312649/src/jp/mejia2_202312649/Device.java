package jp.mejia2_202312649;

public interface Device {
	public void turnOn() {

	}
	public default turnOff() {
		
	}
	public default String getStatus() {
		return null;
	}
}
