package jp.mejia2_202312649;

public class Thermostat {
	private double temperature;
	
	public Thermostat(int id) {
		
	}
	public String setTemperature(double temp) {
		return temperature;
		
	}
}
