package jp.mejia2_202312649;

public class Camera {
	public static String HD ="HD";
	public static String FHD ="FULL HD";
	public static String FOUR_K ="4K";
	private String resolution;
	
	public Camera(int id, String resolution) {
		
	}
	public String getStatus() {
		return null;
	}
}
